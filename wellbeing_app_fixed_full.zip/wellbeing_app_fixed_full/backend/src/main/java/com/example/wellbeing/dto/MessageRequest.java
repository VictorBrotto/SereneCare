package com.example.wellbeing.dto;

public class MessageRequest {
    private String content;

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
}
