package com.example.wellbeing.dto;

public class DailyLogDTO {
    public Long userId;
    public Integer painLevel;
    public Integer sleepQuality;
    public Integer mood;
    public String symptoms;
    public String triggers;
    public String dietMeals;
    public String physicalActivity;
    public String medications;
    public String additionalNotes;
}
